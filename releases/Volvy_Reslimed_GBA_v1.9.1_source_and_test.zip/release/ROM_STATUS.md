# Volvy GBA v1.9 experimental ROM status

- Version: 1.9 — source-only green hole marker suppressed.
- Compiler: experimental Clang/LLD ARM7TDMI bare-metal pipeline (not devkitARM/libgba).
- ROM image size: 2,097,152 bytes (2 MiB).
- Payload size: 1,240,652 bytes.
- Source files compiled: 41 C translation units.
- GBA header, Nintendo logo prefix, checksum and ELF section checks: PASS.
- Host C regression suite: PASS.
- Source marker asset/render exclusion test: PASS.
- ARMv4T/Thumb code generation: PASS (40 translation units with test-only headers).
- devkitARM/libgba build: NOT VERIFIED (`DEVKITARM` is not configured here).
- mGBA boot and visual retest: NOT TESTED (mGBA executable is unavailable here).
- Physical GBA: NOT TESTED.

The supplied capture shows a running build but does not expose a ROM checksum, so it cannot identify the v1.8 or v1.9 binary.
