#ifndef VOLVY_PLAYER_SPRITES_H
#define VOLVY_PLAYER_SPRITES_H

#include <stdint.h>

typedef struct GbaSpritePart {
    const uint8_t *tiles;
    uint16_t tile_bytes;
    uint8_t offset_x;
    uint8_t offset_y;
    uint8_t hw_w;
    uint8_t hw_h;
    uint8_t shape;
    uint8_t size_code;
} GbaSpritePart;

typedef struct GbaSpriteFrame {
    const GbaSpritePart *parts;
    uint8_t part_count;
    uint8_t width;
    uint8_t height;
    uint8_t origin_x;
    uint8_t origin_y;
} GbaSpriteFrame;

typedef struct GbaSpriteAnim {
    const GbaSpriteFrame *frames;
    uint8_t frame_count;
    uint8_t frame_duration;
} GbaSpriteAnim;

extern const uint16_t g_player_obj_palette[256];
extern const GbaSpriteAnim g_spr_action_block_spent;
extern const GbaSpriteAnim g_spr_action_block;
extern const GbaSpriteAnim g_spr_bumper_sq;
extern const GbaSpriteAnim g_spr_bumper_tri;
extern const GbaSpriteAnim g_spr_bunny_hop;
extern const GbaSpriteAnim g_spr_dash_up;
extern const GbaSpriteAnim g_spr_dash;
extern const GbaSpriteAnim g_spr_destructible_block_swolvy;
extern const GbaSpriteAnim g_spr_destructible_block;
extern const GbaSpriteAnim g_spr_dig_swole;
extern const GbaSpriteAnim g_spr_dig;
extern const GbaSpriteAnim g_spr_float;
extern const GbaSpriteAnim g_spr_grind;
extern const GbaSpriteAnim g_spr_ground_pound;
extern const GbaSpriteAnim g_spr_idle;
extern const GbaSpriteAnim g_spr_jump;
extern const GbaSpriteAnim g_spr_onion;
extern const GbaSpriteAnim g_spr_punch_up;
extern const GbaSpriteAnim g_spr_punch;
extern const GbaSpriteAnim g_spr_springboard;
extern const GbaSpriteAnim g_spr_squirrel_hurt;
extern const GbaSpriteAnim g_spr_squirrel_idle;
extern const GbaSpriteAnim g_spr_squirrel_walk;
extern const GbaSpriteAnim g_spr_swim_dash;
extern const GbaSpriteAnim g_spr_swim;
extern const GbaSpriteAnim g_spr_swolvy_float;
extern const GbaSpriteAnim g_spr_swolvy_grind;
extern const GbaSpriteAnim g_spr_swolvy_ground_pound;
extern const GbaSpriteAnim g_spr_swolvy_idle;
extern const GbaSpriteAnim g_spr_swolvy_jump;
extern const GbaSpriteAnim g_spr_swolvy_punch_up;
extern const GbaSpriteAnim g_spr_swolvy_punch;
extern const GbaSpriteAnim g_spr_swolvy_swim;
extern const GbaSpriteAnim g_spr_swolvy_transform;
extern const GbaSpriteAnim g_spr_swolvy_walk;
extern const GbaSpriteAnim g_spr_volvy_clear;
extern const GbaSpriteAnim g_spr_volvy_collect;
extern const GbaSpriteAnim g_spr_volvy_hurt;
extern const GbaSpriteAnim g_spr_volvy_title;
extern const GbaSpriteAnim g_spr_volvy_windup;
extern const GbaSpriteAnim g_spr_walk;
extern const GbaSpriteAnim g_spr_cloud_platform;
extern const GbaSpriteAnim g_spr_moving_platform;
extern const GbaSpriteAnim g_spr_moving_platform_wide;

#endif
