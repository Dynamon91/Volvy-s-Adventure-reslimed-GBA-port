#ifndef VOLVY_BOSS_SPRITES_H
#define VOLVY_BOSS_SPRITES_H
#include <stdint.h>
#include "player_sprites.h"
extern const uint16_t g_boss_obj_palette[256];
extern const GbaSpriteAnim g_boss_spr_autohole;
extern const GbaSpriteAnim g_boss_spr_cage_grunfus;
extern const GbaSpriteAnim g_boss_spr_dash_up;
extern const GbaSpriteAnim g_boss_spr_dash;
extern const GbaSpriteAnim g_boss_spr_dig_swole;
extern const GbaSpriteAnim g_boss_spr_dig;
extern const GbaSpriteAnim g_boss_spr_emitter_direction;
extern const GbaSpriteAnim g_boss_spr_float;
extern const GbaSpriteAnim g_boss_spr_grind;
extern const GbaSpriteAnim g_boss_spr_ground_pound;
extern const GbaSpriteAnim g_boss_spr_hivefly_hurt;
extern const GbaSpriteAnim g_boss_spr_hivefly;
extern const GbaSpriteAnim g_boss_spr_idle;
extern const GbaSpriteAnim g_boss_spr_jump;
extern const GbaSpriteAnim g_boss_spr_mega_boulder;
extern const GbaSpriteAnim g_boss_spr_mole_dig_enter;
extern const GbaSpriteAnim g_boss_spr_mole_dig_exit_no_inbetween;
extern const GbaSpriteAnim g_boss_spr_mole_dig_exit;
extern const GbaSpriteAnim g_boss_spr_mole_dig_surface;
extern const GbaSpriteAnim g_boss_spr_mole_dig_underground_hurt;
extern const GbaSpriteAnim g_boss_spr_mole_dig_underground_hurtmask;
extern const GbaSpriteAnim g_boss_spr_mole_dig_underground;
extern const GbaSpriteAnim g_boss_spr_mole_hole;
extern const GbaSpriteAnim g_boss_spr_mole_hurt;
extern const GbaSpriteAnim g_boss_spr_mole_idle_surface_digging;
extern const GbaSpriteAnim g_boss_spr_mole_idle_surface;
extern const GbaSpriteAnim g_boss_spr_onion;
extern const GbaSpriteAnim g_boss_spr_punch_up;
extern const GbaSpriteAnim g_boss_spr_punch;
extern const GbaSpriteAnim g_boss_spr_shrewy_dropkick;
extern const GbaSpriteAnim g_boss_spr_shrewy_hurt;
extern const GbaSpriteAnim g_boss_spr_shrewy_idle;
extern const GbaSpriteAnim g_boss_spr_shrewy_jump;
extern const GbaSpriteAnim g_boss_spr_shrewy_rock;
extern const GbaSpriteAnim g_boss_spr_shrewy_stomp;
extern const GbaSpriteAnim g_boss_spr_shrewy_tornado_slam;
extern const GbaSpriteAnim g_boss_spr_shrewy_tornado;
extern const GbaSpriteAnim g_boss_spr_shrewy_windup;
extern const GbaSpriteAnim g_boss_spr_snake_hurt;
extern const GbaSpriteAnim g_boss_spr_snake_idle;
extern const GbaSpriteAnim g_boss_spr_snake_walk;
extern const GbaSpriteAnim g_boss_spr_swim_dash;
extern const GbaSpriteAnim g_boss_spr_swim;
extern const GbaSpriteAnim g_boss_spr_swolvy_float;
extern const GbaSpriteAnim g_boss_spr_swolvy_grind;
extern const GbaSpriteAnim g_boss_spr_swolvy_ground_pound;
extern const GbaSpriteAnim g_boss_spr_swolvy_idle;
extern const GbaSpriteAnim g_boss_spr_swolvy_jump;
extern const GbaSpriteAnim g_boss_spr_swolvy_punch_up;
extern const GbaSpriteAnim g_boss_spr_swolvy_punch;
extern const GbaSpriteAnim g_boss_spr_swolvy_swim;
extern const GbaSpriteAnim g_boss_spr_swolvy_transform;
extern const GbaSpriteAnim g_boss_spr_swolvy_walk;
extern const GbaSpriteAnim g_boss_spr_tnt_triggered;
extern const GbaSpriteAnim g_boss_spr_tnt;
extern const GbaSpriteAnim g_boss_spr_volvy_clear;
extern const GbaSpriteAnim g_boss_spr_volvy_hurt;
extern const GbaSpriteAnim g_boss_spr_walk;

#endif
