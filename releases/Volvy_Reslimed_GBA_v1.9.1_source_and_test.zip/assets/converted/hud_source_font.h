#ifndef VOLVY_HUD_SOURCE_FONT_H
#define VOLVY_HUD_SOURCE_FONT_H
#include <stdint.h>
#define VOLVY_HUD_FONT_TILES 40u
#define VOLVY_HUD_FONT_BYTES (VOLVY_HUD_FONT_TILES * 32u)
extern const uint8_t g_hud_source_font_tiles[VOLVY_HUD_FONT_BYTES];
#endif
