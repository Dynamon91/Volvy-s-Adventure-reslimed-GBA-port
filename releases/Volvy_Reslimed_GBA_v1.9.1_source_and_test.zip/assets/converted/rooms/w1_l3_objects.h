#ifndef VOLVY_W1_L3_OBJECTS_H
#define VOLVY_W1_L3_OBJECTS_H
#include "world_objects.h"
#define W1_L3_COLLISION_WIDTH 142
#define W1_L3_COLLISION_HEIGHT 32
#define W1_L3_OBJECT_COUNT 502
#define W1_L3_ONION_COUNT 318
extern const uint8_t w1_l3_collision[W1_L3_COLLISION_WIDTH * W1_L3_COLLISION_HEIGHT];
extern const WorldObject w1_l3_objects[W1_L3_OBJECT_COUNT];
#endif
