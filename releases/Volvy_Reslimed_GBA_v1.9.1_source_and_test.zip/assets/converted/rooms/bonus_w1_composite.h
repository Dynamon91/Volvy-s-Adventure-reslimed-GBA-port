#ifndef BONUS_W1_COMPOSITE_H
#define BONUS_W1_COMPOSITE_H
#include <stdint.h>
#define BONUS_W1_COMPOSITE_MAP_WIDTH 332
#define BONUS_W1_COMPOSITE_MAP_HEIGHT 70
#define BONUS_W1_COMPOSITE_TILE_COUNT 486
#define BONUS_W1_COMPOSITE_TILE_BYTES 31104
#define BONUS_W1_COMPOSITE_OPAQUE_COLORS 24
#define BONUS_W1_COMPOSITE_SCENE_WIDTH 2656
#define BONUS_W1_COMPOSITE_SCENE_HEIGHT 560
extern const uint8_t bonus_w1_composite_tiles[31104];
extern const uint16_t bonus_w1_composite_palette[256];
extern const uint16_t bonus_w1_composite_map[23240];
#endif
