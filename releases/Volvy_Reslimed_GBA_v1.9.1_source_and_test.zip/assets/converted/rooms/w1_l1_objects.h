#ifndef VOLVY_W1_L1_OBJECTS_H
#define VOLVY_W1_L1_OBJECTS_H
#include "world_objects.h"
#define W1_L1_COLLISION_WIDTH 142
#define W1_L1_COLLISION_HEIGHT 32
#define W1_L1_OBJECT_COUNT 214
#define W1_L1_ONION_COUNT 84
extern const uint8_t w1_l1_collision[W1_L1_COLLISION_WIDTH * W1_L1_COLLISION_HEIGHT];
extern const WorldObject w1_l1_objects[W1_L1_OBJECT_COUNT];
#endif
