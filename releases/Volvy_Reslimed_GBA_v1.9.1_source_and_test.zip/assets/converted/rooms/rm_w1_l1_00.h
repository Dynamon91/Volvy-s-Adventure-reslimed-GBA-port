#ifndef RM_W1_L1_00_GBA_H
#define RM_W1_L1_00_GBA_H
#include <stdint.h>
#define RM_W1_L1_00_MAP_WIDTH 142
#define RM_W1_L1_00_MAP_HEIGHT 23
#define RM_W1_L1_00_TILE_COUNT 50
#define RM_W1_L1_00_PALETTE_COLORS 27
#define RM_W1_L1_00_ROOM_WIDTH_SOURCE 2258
#define RM_W1_L1_00_ROOM_HEIGHT_SOURCE 360
extern const uint8_t rm_w1_l1_00_tiles[];
extern const uint16_t rm_w1_l1_00_palette[256];
extern const uint16_t rm_w1_l1_00_map[3266];
#endif
