#ifndef VOLVY_WORLD_OBJECTS_H
#define VOLVY_WORLD_OBJECTS_H
#include <stdint.h>
typedef enum WorldObjectType {
    WORLD_ONION=1, WORLD_BREAKABLE, WORLD_ACTION_BLOCK, WORLD_SQUIRREL,
    WORLD_SPRINGBOARD, WORLD_EXIT_RIGHT, WORLD_EXIT_UP, WORLD_EXIT_DOWN,
    WORLD_HIVEFLY, WORLD_HOLE, WORLD_PLANT, WORLD_WORM, WORLD_LEVEL_EXIT_HOLE
} WorldObjectType;
typedef struct WorldObject {
    uint16_t kind;
    int16_t x, y; /* original source instance pivot, divided by 2 */
    int16_t left, top; /* sprite AABB, divided by 2 */
    uint8_t width, height;
} WorldObject;
#endif
