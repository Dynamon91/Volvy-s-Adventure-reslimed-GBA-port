#ifndef VOLVY_SHREWY_ROOM_H
#define VOLVY_SHREWY_ROOM_H
#include <stdint.h>
#define SHREWY_ROOM_WIDTH 256
#define SHREWY_ROOM_HEIGHT 144
#define SHREWY_ROOM_GRID_WIDTH 32
#define SHREWY_ROOM_GRID_HEIGHT 18
#define SHREWY_ROOM_PROP_COUNT 15
#define SHREWY_ROOM_SOLID_OBJECTS 3
#define SHREWY_ROOM_ONEWAY_OBJECTS 1
#define SHREWY_BOSS_SOURCE_X 184
#define SHREWY_BOSS_SOURCE_Y 104
#define SHREWY_PLAYER_SOURCE_X 64
#define SHREWY_PLAYER_SOURCE_Y 160
#define SHREWY_ARENA_FLOOR_Y 112
typedef enum ShrewyPropKind {
    SHREWY_PROP_ONION=1, SHREWY_PROP_CAGE, SHREWY_PROP_AUTOHOLE,
    SHREWY_PROP_EMITTER, SHREWY_PROP_AUTODIGGER
} ShrewyPropKind;
typedef struct ShrewyProp {
    uint16_t kind;
    uint16_t reserved;
    uint32_t source_id;
    int16_t x, y, left, top;
    uint8_t width, height;
    int16_t scale_x_q8, scale_y_q8, rotation_tenths;
} ShrewyProp;
extern const uint8_t shrewy_collision[SHREWY_ROOM_GRID_WIDTH * SHREWY_ROOM_GRID_HEIGHT];
extern const ShrewyProp shrewy_props[SHREWY_ROOM_PROP_COUNT];
#endif
