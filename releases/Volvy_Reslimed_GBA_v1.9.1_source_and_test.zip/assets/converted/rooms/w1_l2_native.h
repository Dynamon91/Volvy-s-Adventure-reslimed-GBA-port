#ifndef W1_L2_NATIVE_H
#define W1_L2_NATIVE_H
#include "core/native_scene.h"
extern const NativeSceneAsset g_w1_l2_native_scene;
#endif
