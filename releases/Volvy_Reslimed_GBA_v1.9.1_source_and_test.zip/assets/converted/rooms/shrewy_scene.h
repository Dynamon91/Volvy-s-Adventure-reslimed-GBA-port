#ifndef SHREWY_SCENE_H
#define SHREWY_SCENE_H
#include <stdint.h>
#define SHREWY_SCENE_MAP_WIDTH 32
#define SHREWY_SCENE_MAP_HEIGHT 18
#define SHREWY_SCENE_TILE_COUNT 417
#define SHREWY_SCENE_PALETTE_COLORS 34
#define SHREWY_SCENE_SCENE_WIDTH 256
#define SHREWY_SCENE_SCENE_HEIGHT 144
extern const uint8_t shrewy_scene_tiles[];
extern const uint16_t shrewy_scene_palette[256];
extern const uint16_t shrewy_scene_map[576];
#endif
