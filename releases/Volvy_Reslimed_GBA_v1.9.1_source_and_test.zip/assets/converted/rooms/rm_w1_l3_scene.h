#ifndef RM_W1_L3_SCENE_H
#define RM_W1_L3_SCENE_H
#include <stdint.h>
#define RM_W1_L3_SCENE_MAP_WIDTH 142
#define RM_W1_L3_SCENE_MAP_HEIGHT 23
#define RM_W1_L3_SCENE_TILE_COUNT 473
#define RM_W1_L3_SCENE_PALETTE_COLORS 34
#define RM_W1_L3_SCENE_SCENE_WIDTH 1129
#define RM_W1_L3_SCENE_SCENE_HEIGHT 180
extern const uint8_t rm_w1_l3_scene_tiles[];
extern const uint16_t rm_w1_l3_scene_palette[256];
extern const uint16_t rm_w1_l3_scene_map[3266];
#endif
