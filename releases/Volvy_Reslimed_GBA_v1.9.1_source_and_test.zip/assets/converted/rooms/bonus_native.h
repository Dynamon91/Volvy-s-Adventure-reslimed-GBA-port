#ifndef BONUS_NATIVE_H
#define BONUS_NATIVE_H
#include "core/native_scene.h"
extern const NativeSceneAsset g_bonus_native_scene;
#endif
