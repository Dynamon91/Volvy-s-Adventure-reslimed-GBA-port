#ifndef SHREWY_NATIVE_H
#define SHREWY_NATIVE_H
#include "core/native_scene.h"
extern const NativeSceneAsset g_shrewy_native_scene;
#endif
