#ifndef VOLVY_SHREWY_CAGE_SEQUENCE_H
#define VOLVY_SHREWY_CAGE_SEQUENCE_H
#include <stdint.h>
#include "core/fixed.h"
#define SHREWY_CAGE_SEQUENCE_FPS 60
#define SHREWY_CAGE_SEQUENCE_FRAMES 60
#define SHREWY_CAGE_POSITION_KEY_LENGTH 67
extern const fx32 shrewy_cage_drop_y_q12[SHREWY_CAGE_SEQUENCE_FRAMES];
#endif
