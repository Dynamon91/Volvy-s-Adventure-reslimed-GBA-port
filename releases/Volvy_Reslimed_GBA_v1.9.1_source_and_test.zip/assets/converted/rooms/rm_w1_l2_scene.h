#ifndef RM_W1_L2_SCENE_H
#define RM_W1_L2_SCENE_H
#include <stdint.h>
#define RM_W1_L2_SCENE_MAP_WIDTH 142
#define RM_W1_L2_SCENE_MAP_HEIGHT 23
#define RM_W1_L2_SCENE_TILE_COUNT 453
#define RM_W1_L2_SCENE_PALETTE_COLORS 40
#define RM_W1_L2_SCENE_SCENE_WIDTH 1129
#define RM_W1_L2_SCENE_SCENE_HEIGHT 180
extern const uint8_t rm_w1_l2_scene_tiles[];
extern const uint16_t rm_w1_l2_scene_palette[256];
extern const uint16_t rm_w1_l2_scene_map[3266];
#endif
