#ifndef BONUS_W1_BUMPER_BOUNDS_H
#define BONUS_W1_BUMPER_BOUNDS_H
#include <stdint.h>
#define BONUS_W1_BUMPER_COUNT 10
/* Offline AABBs from original 16x16 sprites, origins, instance transforms. */
typedef struct BonusBumperHitbox {
    uint16_t instance_index;
    int16_t x, y;
    uint8_t width, height, corner;
} BonusBumperHitbox;
extern const BonusBumperHitbox bonus_w1_bumpers[BONUS_W1_BUMPER_COUNT];
#endif
