#ifndef VOLVY_W1_L2_OBJECTS_H
#define VOLVY_W1_L2_OBJECTS_H
#include "world_objects.h"
#define W1_L2_COLLISION_WIDTH 142
#define W1_L2_COLLISION_HEIGHT 32
#define W1_L2_OBJECT_COUNT 367
#define W1_L2_ONION_COUNT 180
extern const uint8_t w1_l2_collision[W1_L2_COLLISION_WIDTH * W1_L2_COLLISION_HEIGHT];
extern const WorldObject w1_l2_objects[W1_L2_OBJECT_COUNT];
#endif
