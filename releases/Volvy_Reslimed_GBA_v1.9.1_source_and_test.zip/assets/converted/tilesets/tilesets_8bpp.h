#ifndef VOLVY_TILESETS_8BPP_H
#define VOLVY_TILESETS_8BPP_H

#include <stdint.h>

typedef struct GbaTileset8bpp {
    const uint8_t *tiles;
    const uint16_t *palette;
    const uint16_t *map;
    uint16_t tile_count;
    uint16_t palette_count;
    uint8_t map_width;
    uint8_t map_height;
} GbaTileset8bpp;

extern const GbaTileset8bpp g_TileSet_beach;
extern const GbaTileset8bpp g_TileSet_boardwalk;
extern const GbaTileset8bpp g_TileSet_bonus;
extern const GbaTileset8bpp g_TileSet_burrow;
extern const GbaTileset8bpp g_TileSet_factory;
extern const GbaTileset8bpp g_TileSet_forest;
extern const GbaTileset8bpp g_TileSet_office;
extern const GbaTileset8bpp g_TileSet_park;
extern const GbaTileset8bpp g_TileSet_pipes;
extern const GbaTileset8bpp g_TileSet_roof;
extern const GbaTileset8bpp g_TileSet_sewer;
extern const GbaTileset8bpp g_TileSet_shipping;
extern const GbaTileset8bpp g_TileSet_subway;
extern const GbaTileset8bpp g_TileSet_underground_2;
extern const GbaTileset8bpp g_TileSet_underground_3;
extern const GbaTileset8bpp g_TileSet_underground_5;
extern const GbaTileset8bpp g_TileSet_underground;
extern const GbaTileset8bpp g_TileSet1;

#endif
